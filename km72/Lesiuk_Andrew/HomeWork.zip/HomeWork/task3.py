x=input('Введіть своє ім’я:')
print('Hello',x,'!')
